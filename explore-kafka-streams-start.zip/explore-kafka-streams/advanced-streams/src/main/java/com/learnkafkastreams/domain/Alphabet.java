package com.learnkafkastreams.domain;

public record Alphabet(
        String abbreviation,
        String description
) {

}
